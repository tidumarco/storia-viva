export const environment = {
  production: true,
  apiBaseUrl: 'https://YOUR-BACKEND-URL.onrender.com'  // ← change after deploying backend
};
